var booking_move = [];
var mouse_pos = [];
var mouse_selection_begin = [];
var selecting = false;


$.fn.extend({
	newData: function(name, val){
		if(!name) return $(this).data();
		if(!val) return $(this).data(name);
		$(this).data(name, val);
		$(this).attr('data-'+name, val);
		return $(this);
	}
});

$(function(){
	diary.timer();
});

var ajax = {
	url: 'ajax.php',
	post: function(method, action, fields, func){
		if(!fields) fields = {};
		fields.method = method;
		fields.action = action;
		$.ajax({
			type: "POST",
			url: ajax.url,
			data: fields,
			dataType: "json",
			success: function(data){
				$('#application.invalid-connection').removeClass('invalid-connection');
				if(func) func(data);
			},
			error: function(data){
				console.log(data);
				console.log('failed to load: '+action);
				$('#application').addClass('invalid-connection'); //alert('lost connection?');
			}
		});
	}
}

var diary = {
	add: {
		reservation: function(staff_id, start_time, end_time, success_function, error_function){
			console.log('Running diary.add.reservation');
			console.log(staff_id, start_time, end_time);
			loading.show();
			ajax.post('data', 'add.diary.reservation', {staff_id: staff_id, start_time: start_time, end_time: end_time}, function(data){
				if(success_function && data.success == 1) success_function(data);
				if(error_function && data.success == 0) error_function(data);				
				loading.hide();
			});
		}
	},
	remove: {
		reservation: function(id, success_function, error_function){
			console.log('Running diary.remove.reservation');
			console.log(id);
			loading.show();
			ajax.post('data', 'remove.diary.reservation', {entry_id: id}, function(data){
				if(success_function && data.success == 1) success_function(data);
				if(error_function && data.success == 0) error_function(data);
				loading.hide();
			});
		}
	},
	update: {
		reservation: function(id, start_time, end_time, success_function, error_function){
			console.log('Running diary.update.reservation');
			console.log(id, start_time, end_time);
			loading.show();
			ajax.post('data', 'update.diary.reservation', {entry_id: id, start_time: start_time, end_time: end_time}, function(data){
				if(success_function && data.success == 1) success_function(data);
				if(error_function && data.success == 0) error_function(data);
				loading.hide();
			});
		}
	},
	refresh: {
		prevent:false,
		time: function(){
			var current_time = moment().tz('Australia/Melbourne');
			var hours = current_time.format('H');
			var minutes = current_time.format('m');
			var time_row = '.h'+hours+'.m'+(Math.floor(minutes / 10) * 10);
			$('.current-time').removeClass('current-time');
			$(time_row).addClass('current-time');
		},
		items: function(){
			ajax.post('data', 'diary.items', {date:$('#diary').newData('date')}, function(data){
				if(diary.refresh.prevent) return;
				$('.reserved:not([class^="adding-reservation-"])').removeClass('reserved').attr('data-reservation-id', '').attr('data-reservation-slots');
				$.each(data.reservations, function(index, row){
					[h, m] = row.start_time.split(':');
					h = h[0] == "0" ? h[1] : h;
					m = m[0] == "0" ? m[1] : m;
					var $field = $('.diary-col[data-staff-id="'+row.staff_id+'"] .diary-row[data-hour="'+h+'"][data-minute="'+m+'"]');
					$field.addClass('reserved').attr('data-reservation-id', row.entry_id).attr('data-reservation-slots', row.time_slots)
					for(var i=1; i<row.time_slots; i++){
						var $field = $field.next();
						$field.addClass('reserved').attr('data-reservation-id', row.entry_id);
					}
				});
			});
		},
	},
	row_details: function(row){
		var h = ("0" + row.newData('hour')).slice(-2);
		var m = ("0" + row.newData('minute')).slice(-2);
		return {
			h:h,
			m:m,
			date: $('#diary').newData('date') + ' ' + h + ':' + m + ':' + '00', 
			staff_id: row.closest('.diary-col').newData('staff-id'),
			row: row
		}
	},
	timer: function(){
		diary.refresh.time();
		diary.refresh.items();
		setTimeout(function(){
			diary.timer();
		},5000);
	}
}

var loading = {
	animation:{},
	show: function(){
		if(this.visible()) return;
		var $el = $('<div class="loading">Loading...</div>').appendTo('body');
		$el.fadeIn();
		return;
	},
	hide: function(){
		$('.loading').stop().fadeOut('fast', function(){
			$(this).remove();
		});
		return;
	},
	visible: function(){
		return $('.loading').length ? true : false;
	}
}


var highlight = {
	clear: function(){
		$('.highlight').removeClass('highlight invalid');
	}
}
var selection = {
	clear: function(){
		$('.selected').removeClass('selected');
	}
}

var reservation = {
	siblings: function(row){
		staff_id = row.closest('.diary-col').attr('staff-id');
		if(row.prev('.reserved, .adding-reservation-'+staff_id).length) row = row.prevUntil('.diary-row:not(.reserved):not(.adding-reservation-'+staff_id+'), .diary-row.removing-reservation');
		if(row.next('.reserved, .adding-reservation-'+staff_id).length) row = row.nextUntil('.diary-row:not(.reserved):not(.adding-reservation-'+staff_id+'), .diary-row.removing-reservation').addBack();
		return row;
	},	
	update_siblings_id: function(row, id) {
		var rows = this.siblings(row);
		rows.attr('data-reservation-id', id);
	},
	selected_rows: function(){
		return $('.diary-row.selected.reserved');
	},
	selected_ids: function() {
		var ids = [];
		$.each(this.selected_rows(), function(index, row){
			var id = $(row).attr('data-reservation-id');
			if(ids.indexOf(id) < 0) ids.push(id);
		});
		return ids;
	},
	group_details_by_class: function(row, class_name){
		if(!row.length) return false;
		if(row.prev().hasClass('.'+class_name)) row = row.prevUntil('.diary-row:not(.'+class_name+')');
		var first = diary.row_details(row);
		var id = row.attr('data-reservation-id');
		var count = 1;
		while(true){
			if(row.next('.diary-row.'+class_name).length){
				row = row.next('.diary-row.'+class_name);
				count++;
			} else {
				var last = diary.row_details(row);
				break;
			}
		}
		return {id: id, start_date: first.date, end_date: last.date, slots: count, staff_id: first.staff_id, start_row:first.row}
	},
	group_details: function(row){
		if(!row.length) return false;
		if(row.prev().hasClass('.reserved')) row = row.prevUntil('.diary-row:not(.reserved), .diary-row.removing-reservation');
		var first = diary.row_details(row);
		var id = row.attr('data-reservation-id');
		var staff_id = row.closest('.diary-col').attr('staff-id');
		var count = 1;
		while(true){
			if(row.next('.diary-row.reserved:not(.removing-reservation), .diary-row.adding-reservation-'+staff_id+':not(.removing-reservation)').length){
				row = row.next('.diary-row.reserved:not(.removing-reservation), .diary-row.adding-reservation-'+staff_id+':not(.removing-reservation)');
				count++;
			} else {
				var last = diary.row_details(row);
				break;
			}
		}
		return {id: id, start_date: first.date, end_date: last.date, slots: count, staff_id: first.staff_id, start_row:first.row}
	},
	rows_by_id: function(id){
		return $('.diary-row[data-reservation-id="'+id+'"]');
	},
	remove_by_id: function(id){
		$('.reserved[data-reservation-id="'+id+'"]').removeClass('reserved');
		diary.remove.reservation(id, function(data){
			reservation.unset_by_id(id);
		}, function(data){
			$('.reserved[data-reservation-id="'+id+'"]').addClass('reserved');
		});
	},
	unset_by_id: function(id){
		var rows = reservation.rows_by_id(id);
		rows.removeClass('reserved removing-reservation').attr('data-reservation-id','');
	},
	remove_pending_by_id: function(id){
		var rows = this.rows_by_id(id);
		rows.filter('.removing-reservation').removeClass('removing-reservation').attr('data-reservation-id','');
	},
	add: function(){
		var cols = [];
		$('.diary-row.selected').each(function(){
			var staff_id = $(this).closest('.diary-col').newData('staff-id');
			if(typeof cols[staff_id] == "undefined") cols[staff_id] = [];
			$(this).addClass('reserved adding-reservation-'+staff_id);
			cols[staff_id].push($(this));
		});
		selection.clear();
		$.each(cols, function(staff_id, rows){
			if(typeof rows == "undefined") return;
			var group_details = reservation.group_details_by_class(rows[0], 'adding-reservation-'+staff_id);
			diary.add.reservation(staff_id, group_details.start_date, group_details.end_date, function(data){
				reservation.update_siblings_id(rows[0], data.entry_id);
				$('.adding-reservation-'+staff_id).removeClass('adding-reservation-'+staff_id);
			}, function(data){
			});
		});
		
	},
	clear: function (){
		var ids = reservation.selected_ids();
		this.selected_rows().removeClass('reserved').addClass('removing-reservation');	
		$.each(ids, function(index, id){
			var first = reservation.rows_by_id(id).not('.removing-reservation').first();
			var second = reservation.rows_by_id(id).filter('.removing-reservation').last().next();
			if(!first.length){
				reservation.remove_by_id(id);
				return true;
			}
			var first_details = reservation.group_details(first);
			diary.refresh.prevent = true;
			diary.update.reservation(id, first_details.start_date, first_details.end_date, function(data){
				//Success
				if(!second){
					reservation.remove_pending_by_id(id);
					diary.refresh.prevent = false;
					return true;
				}
				var second_details = reservation.group_details(second);
				diary.add.reservation(second_details.staff_id, second_details.start_date, second_details.end_date, function(data){
					//Success
					reservation.update_siblings_id(second_details.start_row, data.entry_id);
					reservation.remove_pending_by_id(id);
					diary.refresh.prevent = false;
				}, function(data){
					//Failed
					diary.refresh.items();
				});
				
			},
			function(data){
				//Failed
				diary.refresh.items();
			});
		});
		selection.clear();	
	}
	
}

var menu = {
	hovering: null,
	is_open: false,
	open: function(){
		if(!menu.is_open){
			menu.is_open = true;
			$('<div id="menu_background" style="display:none;"></div>').appendTo('#frame').fadeIn('fast');
			$('#frame_left_bar').animate({ width: '200px'}, 200);
		}
	},
	close: function(){
		$('#menu_background').fadeOut(function(){
			$(this).remove();
		});
		$('#frame_left_bar').animate({ width: '60px'}, 200, function(){
			menu.is_open = false;
		});		
	}
}


$(function(){
	
	$('button.btn').click(function(){
		return false;
	});
	
	$('#diary .simplebar-content').scroll(function(){
		var left = $(this).scrollLeft();
		$('#diary_headers').css('left', left*-1);
	});
	
	$('#frame_left_bar .frame-btn').on('mouseover', function(){
		menu.hovering = this;
		var current = this;
		setTimeout(function(){
			if(menu.hovering == current) menu.open();
		}, 200);
	});
	
	$('#frame').on('mouseover tap touchstart', '#menu_background', function(e){
		menu.hovering = null;
		menu.close();
	});
	
	$('#frame_left_bar .frame-btn').on('click', function(){
		$('#frame_left_bar .frame-btn').removeClass('active');
		$(this).addClass('active');
	});
	
	$('#frame_top_bar .frame-btn').on('click', function(){
		$('#frame_top_bar .frame-btn').removeClass('active');
		$(this).addClass('active');
	});
	

	$(document).on('mousemove touchmove', function(e){
		mouse_pos.Y = e.pageY; 
		mouse_pos.X = e.pageX;
		
		if(selecting){ 
			row_collision(mouse_selection_begin.Y, mouse_pos.X, mouse_pos.Y, mouse_selection_begin.X, 'selected');
			selection_rectangle(mouse_selection_begin.X, mouse_selection_begin.Y, mouse_pos.X, mouse_pos.Y);
		} else {
			$('#selection-rectangle').remove();
		}
		
		if(!booking_move.initiated && booking_move.selected){
			if(booking_move.move_amount >= 10){
				booking_move_initiate(booking_move.object);
				booking_move_highlight_target();
			}
			booking_move.move_amount++;
		}
	}).on('mouseup touchend', function(e){
		
		if(selecting){ 
			row_collision(mouse_selection_begin.Y, mouse_pos.X, mouse_pos.Y, mouse_selection_begin.X, 'selected');
			selection_rectangle(mouse_selection_begin.X, mouse_selection_begin.Y, mouse_pos.X, mouse_pos.Y);
		} else {
			$('#selection-rectangle').remove();
		}
		
		selecting = false;
	});
	
		
	$('.booking:not(.invoiced)').on("mousedown", function(e){ 
		booking_click(this); 
	});
	
	function booking_click(object){
		booking_move.selected = true;
		booking_move.object = object;
		booking_move.initiated = false;
		booking_move.move_amount = 0;
		booking_move.position = [];
		booking_move.position.X = mouse_pos.X - $(object).offset().left + $('#time').outerWidth() + $('#diary > .simplebar-scroll-content').offset().left;
		booking_move.position.Y = mouse_pos.Y - $(object).offset().top + $('#diary > .simplebar-scroll-content').offset().top;
	}
	
	//$('.diary-row').on('mousedown tap', '.booking:not(.invoiced)', function(){ booking_click(this) })
	
	$('.diary-row').on('taphold', '.booking', function(){
		if(booking_move.initiated) return false;
		if(!booking_move.selected) return false;
		booking_move_initiate(booking_move.object);			
	}).on('mouseup', function(){
		if(booking_move.selected) booking_move_complete();
	});

	
	$(document).on('mousedown', function(e){
		var $visibleMenu = $('.context-menu-list').filter(':visible');
		if ($visibleMenu.length){
			if(!$(e.target).closest('.context-menu-root').length){
				$visibleMenu.trigger('contextmenu:hide', {force: false});
			}
		}
	});
	
	$(document).on('contextmenu', function(e){
		if(($(e.target).hasClass('row selected') || $(e.target).closest('.diary-row.selected').length) && $(e.target).closest('#columns').length){
			//allow right click			
		} else {
			//e.preventDefault();
		}
	});
	
	$('#columns').on('mousedown', function(e){
		if(!$(e.target).hasClass('diary-row')) return;
		mouse_selection_begin.X = e.pageX;
		mouse_selection_begin.Y = e.pageY ;
		if($(e.target).hasClass('selected') && e.which == 3) return;
		selecting = true;
	});

	
	start_functions();
	
});


function start_functions(){
	booking_context_menus();
	booking_move_mouse_follow();
	booking_truncate_text();
	form_elements();
}


function booking_context_menus(){
	
	$.contextMenu({
		selector: 'div.booking:not(.arrived):not(.invoiced)',
		appendTo: 'div#diary',
		trigger: 'right',
		callback: function(key, opt) {
				switch(key){
					case 'arrived': 
						booking_mark_arrived(opt.$trigger);
						break;
					case 'invoice': 
						booking_invoice(opt.$trigger);
						break;
					case 'remove_booking': 
						booking_remove(opt.$trigger);
						break;
				}
				//var m = "clicked: " + key;
				//window.console && console.log(m) || alert(m); 
		},
		items: {
			"arrived": {"name": "Arrived"},
			"invoice": {"name": "Invoice"},
			"sep1": "-----",
			"edit_booking": {"name": "Edit"},
			"remove_booking": {"name": "Remove"},
			"sep2": "-----",
			"view": {
				"name": "View",
				"items": {
					"view_client": {"name": "Client"},
					"view_episode": {"name": "Episode"},
					"view_treatment_notes": {"name": "Treatment Notes"}
				}
			},
			"contact_client": {
				"name": "Contact",
				"items": {
					"send_email": {"name": "Email"},
					"send_sms": {"name": "Text message"}
				}
			}
		}
	});

	$.contextMenu({
		selector: 'div.booking.arrived:not(.invoiced)',
		appendTo: 'div#diary',
		trigger: 'right',
		callback: function(key, opt) {
				switch(key){
					case 'un-arrive': 
						booking_mark_unarrived(opt.$trigger);
						break;
					case 'invoice': 
						booking_invoice(opt.$trigger);
						break;
					case 'remove_booking': 
						booking_remove(opt.$trigger);
						break;
					
				}
				//var m = "clicked: " + key;
				//window.console && console.log(m) || alert(m); 
		},
		items: {
			"un-arrive": {"name": "Un-arrive"},
			"invoice": {"name": "Invoice"},
			"sep1": "-----",
			"edit_booking": {"name": "Edit"},
			"remove_booking": {"name": "Remove"},
			"sep2": "-----",
			"view": {
				"name": "View",
				"items": {
					"view_client": {"name": "Client"},
					"view_episode": {"name": "Episode"},
					"view_treatment_notes": {"name": "Treatment Notes"}
				}
			},
			"contact_client": {
				"name": "Contact",
				"items": {
					"send_email": {"name": "Email"},
					"send_sms": {"name": "Text message"}
				}
			}
		}
	});

	
	$.contextMenu({
		selector: 'div.diary-row.selected:not(.reserved)',
		appendTo: 'div#diary',
		trigger: 'right',
		items: {
			single_booking: {
				name: "Single Booking",
				callback: function(key, opt){
					var info = diary.row_details(opt.$trigger);
					sheets.single_booking.add({start_time: info.date, staff_id: info.staff_id});
				}
			},
			group_booking: {
				name: "Group Booking",
				callback: function(key, opt){
					var info = diary.row_details(opt.$trigger);
					sheets.group_booking.add({start_time: info.date, staff_id: info.staff_id});
				}
			},
			reserve: {
				name: "Reserve",
				callback: function(key, opt){
					reservation.add();					
				}
			}
		}
	});
	
	$.contextMenu({
		selector: 'div.diary-row.selected.reserved',
		appendTo: 'div#diary',
		trigger: 'right',
		items: {
			clear_selection: {
				name: "Clear selection",
				callback: function(key, opt){
					reservation.clear();			
				}
			},
			clear_reservation: {
				name: "Clear reservation",
				callback: function(key, opt){
					var id = opt.$trigger.attr('data-reservation-id');
					reservation.remove_by_id(id);					
				}
			}
		}
	});
}

function selection_rectangle(x1, y1, x2, y2){
	if(!selecting) return;
	if(!$('#selection-rectangle').length) $('#columns').append('<div id="selection-rectangle"></div>');
	if(x1 > x2) x1 = [x2, x2 = x1][0];
	if(y1 > y2) y1 = [y2, y2 = y1][0];
	$('#selection-rectangle').css('top', y1);
	$('#selection-rectangle').css('left', x1);
	$('#selection-rectangle').css('width', x2-x1);
	$('#selection-rectangle').css('height', y2-y1);
}

function row_collision(top, right, bottom, left, classname){
	bottom++;
	if(top > bottom) top = [bottom, bottom = top][0];
	if(left > right) left = [right, right = left][0];
	$('#columns .diary-row').removeClass('selected');
	$('#columns .diary-row').each(function(){
		var row_top = $(this).offset().top;
		var row_left = $(this).offset().left;
		var row_bottom = row_top + $(this).height();
		var row_right = row_left + $(this).width();
		if (bottom < row_top || top > row_bottom || right < row_left || left > row_right){
			// No detection
		} else {
			$(this).addClass(classname);
		}
	});
}


function booking_invoice(object){
	booking_mark_arrived(object);
	if(!$(object).hasClass('invoiced')) $(object).addClass('invoiced');
	//TODO: Database remove;
}
function booking_remove(object){
	$(object).remove();
	//TODO: Database remove;
}

function booking_mark_arrived(object){
	if(!$(object).hasClass('arrived')) $(object).addClass('arrived');
	//TODO: Database mark arrived;
}

function booking_mark_unarrived(object){
	$(object).removeClass('arrived');
	//TODO: Database mark unarrived;
}

function booking_move_initiate(object){
	booking_move.move_amount = 0;
	booking_move.id = $(object).newData('id');
	booking_move.move = true;
	booking_move.move_rows = $(object).newData('length');
	$('.booking').css('pointerEvents', 'none');	
	$(object).addClass('see-through')
		.clone()
		.addClass('new')
		.addClass('mouse-follow')
		.css('width', $(object).outerWidth())
		.css('height', $(object).outerHeight())
		.css('top', mouse_pos.Y - 10 - $('#columns').offset().top)
		.css('left', mouse_pos.X - booking_move.position.X)
		.appendTo('#columns');		
	$(object).addClass('original');
	$(object).closest('.diary-row').nextAll('.diary-row').addBack().slice(0,booking_move.move_rows).removeClass('occupied');
	booking_move.initiated = true;
}

function booking_truncate_text() {
	$('.booking .content').each(function(){
		var wordArray = $(this).html().trim().split(' ');
		var outer_height = $(this).closest('.booking').outerHeight(true) - $(this).closest('.booking').find('.title-bar').outerHeight() - 2;
		while($(this).height() > outer_height) {
			wordArray.pop();
			$(this).html(wordArray.join(' ') + '...');
		}
	});
}

function booking_move_highlight_target(){
	selection.clear();
	highlight.clear();
	var invalid = false;
	$('.diary-col').each(function(){
		if(is_colliding($(this), $('.booking.new'))){
			$(this).find('.diary-row').each(function(){
				if(is_booking_in_row($(this))){
					$(this).addClass('highlight');
					if($(this).hasClass('occupied')) invalid = true;
				}
			});
		}
	});
	var rows = $('.highlight:first').nextAll('.diary-row').addBack().slice(0,booking_move.move_rows);
	rows.each(function(){
		$(this).addClass('highlight');
		if($(this).hasClass('occupied')) invalid = true;
	});
	if(invalid) $('.highlight').addClass('invalid');
}


function booking_move_complete(){
	booking_move.selected = false;
	booking_move.move = false;		
	booking_move.initiated = false;		
	$('.booking').removeClass('mouse-follow');
	if($('.highlight').length === 0 || $('.highlight:first').hasClass('invalid')) booking_move_reset(); else booking_move_confirm();
	highlight.clear();
}

function booking_move_reset(){
	$('.booking').css('pointerEvents', 'all');
	$('.booking.new').remove();
	$('.booking.original').removeClass('original see-through').closest('.diary-row').nextAll('.diary-row').addBack().slice(0,booking_move.move_rows).addClass('occupied');
}

function booking_move_confirm(){
	$('.booking').css('pointerEvents', 'all');
	$('.booking.original').remove();
	$('.booking.new').removeClass('see-through').appendTo('.diary-row.highlight:first').css('top', '').css('left', '').css('width', '').css('height', '');
	$('.booking.new').closest('.diary-row').nextAll('.diary-row').addBack().slice(0,booking_move.move_rows).addClass('occupied');
	$('.booking.new').removeClass('new');
}

function booking_move_mouse_follow(){
	setTimeout(function(){
		if($('.mouse-follow').length){
			var container = [], top = mouse_pos.Y - 10 - $('#columns').offset().top, left = mouse_pos.X - booking_move.position.X;
			container.left = 6;
			container.top = 0;
			container.right = container.left - 10 + $('#columns').outerWidth(true);
			container.bottom = container.top + $('#columns').outerHeight(true);
			if(top < container.top) top = container.top;
			if(left < container.left) left = container.left;
			if(left + $(booking_move.object).outerWidth() > container.right) left = container.right - $(booking_move.object).outerWidth();
			if(top + $(booking_move.object).outerHeight() > container.bottom) top = container.bottom - $(booking_move.object).outerHeight();		
			$('.mouse-follow').css('top', top).css('left', left);
			booking_move_highlight_target();
		}
		booking_move_mouse_follow();
	}, 12);
}




function is_booking_in_row($row){
	var row_height             = $row.outerHeight( true );
	var row_width              = $row.outerWidth( true );
	var row_top							   = $row.offset().top;
	var row_left							 = $row.offset().left;
	var row_bottom				  	 = row_top + row_height;
	var row_right							 = row_left + row_width;

	var row_midpoint = [];
	row_midpoint.X = row_left + row_width/2;
	row_midpoint.Y = row_top + row_height/2;
	
	$booking = $('.booking.new');
	var booking_height             = $booking.outerHeight( true );
	var booking_width              = $booking.outerWidth( true );
	var booking_top					  		 = $booking.offset().top;
	var booking_left					  	 = $booking.offset().left;
	var booking_bottom					   = booking_top + booking_height;
	var booking_right							 = booking_left + booking_width;

	var not_colliding = ( row_midpoint.Y < booking_top || row_midpoint.Y > booking_bottom || row_midpoint.X < booking_left || row_midpoint.X > booking_right );
	//var not_colliding = ( row_bottom < booking_top || row_top > booking_bottom || row_right < booking_left || row_left > booking_right );

	// Return whether it IS colliding
	return ! not_colliding;
};

function is_colliding( $div1, $div2 ) {
	
	var d1_offset             = $div1.offset();
	var d1_height             = $div1.outerHeight( true );
	var d1_width              = $div1.outerWidth( true );
	var d1_distance_from_top  = d1_offset.top + d1_height;
	var d1_distance_from_left = d1_offset.left + d1_width;

	var d2_offset             = $div2.offset();
	var d2_height             = $div2.outerHeight( true );
	var d2_width              = $div2.outerWidth( true );
	var d2_distance_from_top  = d2_offset.top + d2_height;
	var d2_distance_from_left = d2_offset.left + d2_width;

	var not_colliding = ( d1_distance_from_top < d2_offset.top || d1_offset.top > d2_distance_from_top || d1_distance_from_left < d2_offset.left || d1_offset.left > d2_distance_from_left );

	// Return whether it IS colliding
	return ! not_colliding;
};









function form_elements(){
	
	
	$('input[type="date"]').each(function(){
		var $el = $(this);
		var name = $el.attr('name');
		var value = $el.val();
		$el.addClass('date-'+name);
		$el.hide();
		$el.after(
			'<div class="date-wrapper row" data-date-class="date-'+name+'">'+
			'  <div class="col f1">'+
			'    <label></label>'+
			'    <input class="date-element day" type="number" name="'+name+'-day" placeholder="Day" min="1" max="31" />'+
			'  </div>'+
			'  <div class="col f3">'+
			'    <label></label>'+
			'    <select class="date-element month" name="'+name+'-month">'+
			'      <option value="" disabled selected>Month</option>'+
			'      <option value="01">January</option>'+
			'      <option value="02">February</option>'+
			'      <option value="03">March</option>'+
			'      <option value="04">April</option>'+
			'      <option value="05">May</option>'+
			'      <option value="06">June</option>'+
			'      <option value="07">July</option>'+
			'      <option value="08">August</option>'+
			'      <option value="09">September</option>'+
			'      <option value="10">October</option>'+
			'      <option value="11">November</option>'+
			'      <option value="12">December</option>'+
			'    </select>'+
			'  </div>'+
			'  <div class="col f1">'+
			'    <label></label>'+
			'    <input class="date-element year" type="number" name="'+name+'-year" placeholder="Year" min="1900" max="'+(new Date()).getFullYear()+'" />'+
			'  </div>'+
			'</div>'
		);
		
		if(value){
			var date_parts = value.split('-');
			var day = parseInt(date_parts[2], 10);
			$('#'+name+'-year').val(date_parts[0]);
			$('#'+name+'-month').val(date_parts[1]);
			$('#'+name+'-day').val(day);
		}
	});
	
	$(document).on('change', '.date-element', function(){
		var $parent_el = $(this).closest('.date-wrapper');
		var date_class = $parent_el.attr('data-date-class');
		var day = $parent_el.find('.date-element.day').val();
		var month = $parent_el.find('.date-element.month').val();
		var year = $parent_el.find('.date-element.year').val();
		
		if(!day.length || !month.length || !year.length) return false;
		if(day.length == 1) day = '0'+day;
		$('.'+date_class).val(year+'-'+month+'-'+day);		
	});

	
	$('input.autocomplete').each(function(){
		var $el = $(this);
		var $label_el = $(this).prev('label');
		var name = $el.attr('name');
		var data_source = $el.newData('source');
		var minimum = $el.newData('minimum');
		var placeholder = $el.newData('placeholder');
		var value = $el.val();
		var invalid_message = $el.newData('invalid');
		$el.addClass('autocomplete-'+name);
		$el.hide();
		$label_el.addClass('select-label');

		$el.after(
			'<div id="select_div_'+name+'" class="select autocomplete'+(placeholder?' placeholder':'')+'" data-minimum="'+minimum+'" data-source="'+data_source+'" data-value="'+(placeholder?'':$el.val())+'" data-class="autocomplete-'+name+'">'+
			'  <div class="select-value">'+
			'    <input type="text" placeholder="'+placeholder+'" value="'+(value?value:'')+'" autocomplete="nope" />'+
			'  </div>'+
			'  <div class="contents"><div class="helper">Start typing...</div></div>'+
			'  <div class="invalid-message">'+invalid_message+'</div>'+
			'</div>'
		);
		new SimpleBar($('#select_div_'+name+' .contents')[0], { autoHide: false });
	});
	
	$('select').each(function(){
		var $el = $(this);
		var $label_el = $(this).prev('label');
		var $selected_option = $el.find('option:selected');
		var name = $el.attr('name').replace('.', '_');
		var placeholder = $el.attr('placeholder');
		var invalid_message = $el.newData('invalid');
		var options = '';
		$el.addClass('select-'+name);
		$el.hide();
		$label_el.addClass('select-label');
		$el.find('option').each(function(index){
			if(index == 0 && $(this).is(':disabled')){ if($(this).is(':selected')) placeholder = $(this).text(); return true; }
			options += '<div class="select-option" data-value="'+$(this).val()+'">'+$(this).text()+'</div>';
		});
		$el.after(
			'<div id="select_div_'+name+'" class="select'+(placeholder?' placeholder':'')+'" data-value="'+(placeholder?'':$el.val())+'" data-class="select-'+name+'">'+
			'  <div class="select-value">'+
			'    <input type="text" placeholder="'+placeholder+'" value="'+(placeholder?'':$selected_option.text())+'" readonly />'+
			'  </div>'+
			'  <div class="contents">'+
			'    '+options+
			'  </div>'+
			'  <div class="invalid-message">'+invalid_message+'</div>'+
			'</div>'
		);
		new SimpleBar($('#select_div_'+name+' .contents')[0], { autoHide: false });
	});
	
	
	$(document)
	.on('mousedown', '.select.focus:not(.autocomplete) .select-value input', function(e){
		var $select = $(this).closest('.select');
		if($('.select.focus').not($select).length){
			select_blur($('.select.focus').not($select));
			e.preventDefault();
		}
	})
	.on('mousedown', '.select .select-value input', function(e){
		var $select = $(this).closest('.select');
		select_focus($select);
	})
	.on('mouseover', '.select .select-option', function(e){
		var $el = $(this);
		var $select = $(this).closest('.select');
		$select.find('.select-option.active').removeClass('active');
		$el.addClass('active');
	})
	.on('click', '.select .select-option', function(e){
		var $el = $(this);
		var $select = $(this).closest('.select');
		var value = $el.attr('data-value');
		var select_class = $select.attr('data-class');
		$('.'+select_class).val(value).trigger('change');
		$select.attr('data-value', value).removeClass('invalid placeholder');
		$select.find('.select-value input').val($el.text());
		$select.find('.select-option.active').removeClass('active');
		$el.addClass('active');
		var inputs = $(':input');
		var nextInput = inputs.get(inputs.index($('.'+select_class)) + 2);
		select_blur($select)
		if(nextInput)	nextInput.focus();
	}).on('focusin', '.select .select-value input', function(){
		select_focus($(this).closest('.select'));
	});

	function select_focus($select_objects){
		$select_objects.each(function(){
			var $select = $(this);
			$select.addClass('focus');
		});
	}
	
	function select_blur($select_objects){
		$select_objects.each(function(){
			$select = $(this);
			var select_class = $select.attr('data-class');
			$select.find('.select-option.active').removeClass('active');
			$select.find('.select-option[data-value="'+$('.'+select_class).val()+'"]').addClass('active');
			var text_val = $select.find('.select-option.active').text();
			$select.find('.select-value input').val(text_val);
			$select.removeClass('focus');
		});
	}
	
	$(document).on('input', '.select.focus .select-value input', function(e) {
		var $el = $(this);
		var $select = $el.closest('.select');
		var minimum = $select.newData('minimum');
		var data_source = $select.newData('source');
		
		var countries = [
			{value: 'au', title: 'Australia test'},
			{value: 'nz', title: 'New Zealand test'},
		];
		
		$select.find('.select-option').remove();
		$select.find('.contents .helper').show();
		if($el.val().length >= minimum){
			var results = array_search($el.val(), countries);
			if(results.length > 0){
				$select.find('.contents .helper').hide();
				$contents = $select.find('.contents');
				contents_element = $contents[0].SimpleBar.getContentElement();
				$.each( results, function( index, element ) {
					$(contents_element).append('<div class="select-option" data-value="'+element.value+'">'+element.title+'</div>');
				});
				$contents[0].SimpleBar.recalculate();
			} else {
				$select.find('.contents .helper').text('No results found.');
			}
		} else {
			$select.find('.contents .helper').text('Start typing...');
		}
	});
	
	
	$(window).on('mousedown',  function(e){
		if($(e.target).hasClass('.select') || $(e.target).closest('.select').length){
			var $el = $(e.target);
			if($el.closest('.select').length) $el = $el.closest('.select');
			if($('.select.focus').not($el).length) select_blur($('.select.focus').not($el));
		} else {
			if($('.select.focus').length) select_blur($('.select.focus'));
		}
	});


	$(window).keydown(function(e) {

			var $select = $('.select.focus');			
			var allowed_keys = [9, 13, 32, 38, 40];
			if(allowed_keys.indexOf(e.which) < 0 || !$select.length) return;

			var $active = $select.find('.select-option.active');
			if(!$active.length){
				$select.find('.select-option:first').addClass('active');
				return;
			}
			
			var $prev = $active.prev('.select-option');
			var $next = $active.next('.select-option');
			
			switch(e.which) {
					case 9:  // tab					
					case 13: // carriage return
					case 32: // space bar
						$active.trigger('click');
					break;
					case 38: // up
						if(!$prev.length) return;
						$active.removeClass('active');
						$prev.addClass('active');
						
						$el = $prev;
						var option_pos = $el.position().top;
						if(option_pos < 0) $select.find('.simplebar-scroll-content').scrollTop($select.find('.simplebar-scroll-content').scrollTop()+option_pos);
						
					break;
					
					case 40: // down
						if(!$next.length) return;
						$active.removeClass('active');
						$next.addClass('active');
						
						$el = $next;

						var select_height = $select.outerHeight()-$select.find('.select-value').outerHeight() - 20; //20 for select-option container margin				
						var option_top = $el.position().top + $select.find('.simplebar-scroll-content').scrollTop() + $el.outerHeight();
						var scroll = (option_top - select_height > 0 ? option_top - select_height : 0);
						$select.find('.simplebar-scroll-content').scrollTop(scroll);
					break;

					default: return; // exit this handler for other keys
			}
			e.preventDefault(); // prevent the default action (scroll / move caret)
	});

}


function array_search(needle, haystack){
	var search = needle.toLowerCase();
	var results = $.grep(haystack, function( element, index ) {
		var name = element.title.toLowerCase();
		if(name.indexOf(search) >= 0){
			return true;
		} else {
			return false;
		}
	});
	return results;
}