

var sheets = {
	initiated: false,
	listener_id:0,
	size: {
		main: 1440,
		picker: 640
	},
	
	ajax: {
		load: 'ajax.php',
	},
	
	add_listener: function($el, func){
		this.listener_id++;
		$el.addClass('listener');
		$el.newData('listener', sheets.listener_id);
		$el.on( "listener:result", function( event, data ) {
			if(func) func(data);
		});
	},

	show: function(load_content, max_width, opts){
		if(!this.initiated) this.init();
		var $el = $('.practice-sheet-holder .practice-sheet:last');	
		var $sheet = $('<div class="practice-sheet"></div>');
		$sheet.newData('sheet', load_content);
		$sheet.newData('changed', '0');
		if(max_width) $sheet.css('maxWidth', max_width+'px');
		$sheet.css('transform', 'translate('+$(window).width()+'px,0)');
		$('<div class="practice-sheet-overlay"></div>').appendTo('.practice-sheet-holder');
		var $new_sheet = $sheet.appendTo('.practice-sheet-holder');
		this.resize();
		if($el) $el.css('transform', 'translate(0,0)');			
		this.load($new_sheet, load_content, opts);
	},
	
	hide_top_sheet: function(){
		//if(!content_changed)
		var $el = $('.practice-sheet-holder .practice-sheet:last');
		var $overlay = $el.prev('.practice-sheet-overlay');
		if(parseInt($el.newData('changed'))){
			if(!confirm('Content has been changed. Are you sure you want to exit?')) return false;
		}
		$el.css('transform', 'translate('+$(window).width()+'px,0)');
		$el.addClass('removing');
		this.resize();
		$overlay.css('opacity', '0');
		setTimeout(function(){
			$overlay.remove();
			$el.remove();
		}, 400);
	},
	
	resize: function(){
		var $el = $('.practice-sheet-holder .practice-sheet:not(.removing):last');
		if(!$el) return;
		var x_translate = $(window).width() - $el.outerWidth();
		$el.css('transform', 'translate('+x_translate+'px,0)');		
	},
	
	load: function($el, action, fields, hide){
		//TODO: show loading toast.
		loading.show();
		if(!fields) fields = {};
		fields.method = 'data';
		fields.action = action;
		$.ajax({
			type: "POST",
			url: this.ajax.load,
			data: fields,
			dataType: "json",
			success: function(data){
				$el.append(sheets.parse(data));
				if(data.fields){
					if(!$el.hasClass('section-editable')) $el = $el.closest('.section-editable');
					$.each(data.fields, function( index, value ){
						$el.closest().find('[name="'+index+'"]').val(value);
						$el.find('textarea[name="'+index+'"]').html(value);
					});
				}
				if(hide) sheets.hide_top_sheet();
				loading.hide();
			},
			error: function(data){
				console.log('failed to load: '+fields.action);
				console.log(data.responseText);
				loading.hide();
			}
		});
	},
	function_from_string: function(string){
		var scope = window;
		var scopeSplit = string.split('.');
		for (i = 0; i < scopeSplit.length - 1; i++){
			scope = scope[scopeSplit[i]];
			if (scope == undefined){
				console.log('undefined function: '+string);
				return;
			}
		}
		return scope[scopeSplit[scopeSplit.length - 1]];
	},
	run: function(string, opts){
		var func = sheets.function_from_string(string);
		func(opts);
	},
	single_booking: {
		add: function(opts){
			sheets.show('single_booking.add', sheets.size.main, opts);
		}
	},
	group_booking: {
		add: function(opts){
			sheets.show('group_booking.add', sheets.size.main, opts);
		}
	},
	
	booking_type: {
		picker: function(){
			sheets.show('booking_type.picker', sheets.size.picker);
		}
	},
	
	client: {
		picker: function(){
			sheets.show('client.picker', sheets.size.picker);
		}
	},
	
	service_category: {
		picker: function(){
			sheets.show('service_category.picker', sheets.size.picker);
		}
	},
	
	service: {
		picker: function(opts){
			sheets.show('service.picker', sheets.size.picker, opts);
		}
	},
	
	init:function(){

		$('.practice-sheet-holder').on('click', '.btn-close, .practice-sheet-overlay', function(){
			sheets.hide_top_sheet();
			$('.listening.active').find('.picker-active').removeClass('picker-active');
			$('.listening.active').removeClass('listening active');
		});
		
		$('.practice-sheet-holder').on('click', '.section-editable .empty-placeholder', function(){
			var $el = $(this).closest('.section-editable');
			var action = $el.newData('action');
			$el.addClass('listening active');
			$el.find('.picker-single, .picker-multi').first().addClass('picker-active');
			$content = $el.find('.content');
			sheets.add_listener($content, function(data){
				var sheet = $el.closest('.practice-sheet').newData('sheet');
				
				if(data.action == 'load'){
					sheets.load($content, sheet+'.'+data.value, false, true);
					
				} else if(data.action == 'field'){
					$field_div = $el.find('.picker-active').closest('.picker-single, .picker-multi');
					$input_div = $field_div.closest('.input-field');
					$field = $field_div.find('[name*="'+sheet+'.'+data.field+'"]');
					$field_div.removeClass('picker-active');
					if($field_div.is('.picker-multi, .picker-single')){
						var vals = [];
						$input_div.find('[name^="'+sheet+'.'+data.field+'"]').each(function(){
							if($(this).val()) vals.push($(this).val());
						});
						var found_index = vals.indexOf(data.value.toString());
						if(found_index >= 0){
							$field = $input_div.find('[name^="'+sheet+'.'+data.field+'"][value="'+vals[found_index]+'"]');
						} else if($field_div.hasClass('default')){
							if($field_div.hasClass('picker-single')) var $picker = sheets.draw_field.picker_single(sheet+'.'+data.field, data.title, data.value, $field_div.newData('action'), $field_div.newData('parent'), $field_div.newData('default-icon'));
							else var $picker = sheets.draw_field.picker_multi(sheet+'.'+data.field, data.title, data.value, $field_div.newData('action'), $field_div.newData('parent'), $field_div.newData('default-icon'));
							$picker.insertBefore($field_div);
							$field = $picker.find('[name^="'+sheet+'.'+data.field+'"]');
						}
					}
					$input_div.newData('selected', '1');
					$field.newData('title', data.title).val(data.value).trigger('change');
					$el.find('.empty-placeholder').hide();
					$el.find('.content').slideDown();
				}
				sheets.summary_fields();
				sheets.hide_top_sheet();
			});
			
			sheets.run(action);
		});

		$('.practice-sheet-holder').on('click', '.picker-row', function(){
			//var action = $(this).newData('action');
			var fields = false;
			var $el = $('.listener[data-listener="'+sheets.listener_id+'"]');
			$el.trigger('listener:result', $(this).newData());
		});		
		
		$('.practice-sheet-holder').on('click', '.picker-single, .picker-multi', function(){
			var $el = $(this).closest('.section-editable');
			$el.addClass('listening active');			
			var action = $(this).newData('action');
			var $parent = $('[name="'+$(this).newData('parent')+'"]');
			var id = $parent.val();
			$el.find('.picker-active').removeClass('picker-active');
			$(this).addClass('picker-active');
			var opts = {id: id};
			sheets.run(action, opts);
		});		
		
		$('.practice-sheet-holder').on('change', '.picker-single input, .picker-multi input', function(){
			var $section = $(this).closest('.section-editable');
			var name = $(this).attr('name');
			var title = $(this).newData('title');
			var current_title = $(this).prev('.picker-text').text();
			$(this).prev('.picker-text').text(title);
			var picker = $(this).closest('.picker-single, .picker-multi');
			sheets.visuals.flash(picker);
			
			if(title == current_title) return true;
			
			//Reset child elements
			$section.find('[data-parent="'+name+'"]').each(function(){
				$input_holder = $(this).closest('.input-field');
				$input_holder.newData('selected', '0');
				$input_holder.find('input[type="hidden"]').val('').trigger('change');
				$input_holder.find('.picker-single:not(.default), .picker-multi:not(.default)').remove();
			});
			
		});
		this.initiated = true;		
	},
	
	summary_fields: function(){
		$('.summary-field').each(function(){
			$section = $(this).closest('.section-editable');
			var field_name = $(this).newData('name');
			var return_type = $(this).newData('return');
			var $field = $section.find('[name="'+field_name+'"]');
			var content = '';
			if(return_type.indexOf('data-') === 0){
				content = $field.newData(return_type.substring(5));
			} else if(return_type === 'content' && typeof $field.val() !== 'undefined' && $field.val() != ""){
				console.log($field.val());
				content = $field.data('title');
			}
			$(this).newData('content', content);
		});
	},
	
	draw_field:{
		picker_single: function(name, text, value, action, parent, icon){
			var $picker = $('<div class="picker-single"></div>');
			var $text = $('<div class="picker-text">'+text+'</div>');
			var $input = $('<input type="hidden" name="'+name+'" value="'+value+'" />');
			$input.newData('title', text);
			if(action) $picker.newData('action', action);
			if(parent) $picker.newData('parent', parent);
			if(icon) $picker.newData('icon', icon);
			$picker.append($text);
			$picker.append($input);
			return $picker;
		},
		picker_single_default: function(name, text, action, parent, icon, default_icon){
			$picker = sheets.draw_field.picker_single(name, text, '', action, parent, icon);
			if(default_icon) $picker.newData('default-icon', default_icon);
			$picker.addClass('default');
			return $picker;
		},
		picker_multi: function(name, text, value, action, parent, icon){
			var $picker = $('<div class="picker-multi"></div>');
			var $text = $('<div class="picker-text">'+text+'</div>');
			var $input = $('<input type="hidden" name="'+name+'[]" value="'+value+'" />');
			$input.newData('title', text);
			if(action) $picker.newData('action', action);
			if(parent) $picker.newData('parent', parent);
			if(icon) $picker.newData('icon', icon);
			$picker.append($text);
			$picker.append($input);
			return $picker;	
		},
		picker_multi_default: function(name, text, action, parent, icon, default_icon){
			$picker = sheets.draw_field.picker_multi(name, text, '', action, parent, icon);
			if(default_icon) $picker.newData('default-icon', default_icon);
			$picker.addClass('default');
			return $picker;	
		}
	},
	
	visuals: {
		flash: function($el){
			$el.css('transition', '');
			$el.css('backgroundColor', '#00C3D0');			
			setTimeout(function(){
				$el.css('transition', 'background-color 0.35s ease');
				$el.css('backgroundColor', '#eee');
			}, 250);
		}
	},
	parse_object: {
		current_object: '',
		set_current_object: function(value){
			sheets.parse_object.current_object = value;
		},
		has_type: function(data){
			return(typeof data.type !== 'undefined');
		},
		init: function(data){
			if(!sheets.parse_object.has_type(data)) return false;
			var func = sheets.function_from_string('sheets.parse_object.'+(sheets.parse_object.current_object ? sheets.parse_object.current_object+'.' : '')+data.type+'.init');
			console.log('sheets.parse_object.'+(sheets.parse_object.current_object ? sheets.parse_object.current_object+'.' : '')+data.type+'.init');
			var $content = func(data);
			return $content;
		},
		section: {
			init: function(data){
				
				var $wrapper = $('<div></div>');
				var $header = $('<div class="practice-sheet-header"></div>');
				var $row = $('<div class="row no-bottom-margin"></div>');
				$row.append($('<div class="col btn-header btn-close"><i class="material-icons">close</i></div>'));
				$row.append($('<div class="col f1"><h1>'+data.title+'</h1></div>'));
				$row.append($('<div class="col btn-holder"><button class="btn btn-action" disabled>Save</button></div>'));
				$header.append($row);
				$wrapper.append($header);
				var $content = $('<div class="practice-sheet-content"></div>');
				$.each(data.blocks, function( index, block ){
					sheets.parse_object.set_current_object('section');
					var $block = sheets.parse_object.init(block);
					$content.append($block);					
				});
				$wrapper.append($content);
				return $wrapper;
			},
			item_block: {
				init: function(data){
					var $block = $('<div class="section container"></div>');
					if(data.editable) $block.addClass('section-editable');
					if(data.duplication) $block.addClass('section-duplication');
					
					$.each(data.data, function( index, value ){
						$block.newData(''+index, value);
					});
					
					$block.append($('<div class="section-title">'+data.title+'</div>'));
					$block.append($('<div class="empty-placeholder"'+(data.section_visible == 'placeholder'?'':' style="display:none;"')+'><div class="image '+data.placeholder.icon+'"></div><div class="text"><div>'+data.placeholder.text+'</div></div></div>'));
					
					if(data.content){
						sheets.parse_object.set_current_object('section.item_block');
						$section_content = sheets.parse_object.init(data.content);
						if(data.section_visible == 'placeholder') $section_content.hide();
						$block.append($section_content);
					}
					return $block;
				},
				item_content: {
					init: function(data){
						//var content = sheets.parse_object.init(data);
					}
				}
			},
			section_block: {
				init: function(data){
					
					var $block = $('<div class="section container"></div>');
					if(data.editable) $block.addClass('section-editable');
					if(data.duplication) $block.addClass('section-duplication');
					
					$.each(data.data, function( index, value ){
						$block.newData(''+index, value);
					});
					
					$block.append($('<div class="section-title">'+data.title+'</div>'));
					$block.append($('<div class="empty-placeholder"'+(data.section_visible == 'placeholder'?'':' style="display:none;"')+'><div class="image '+data.placeholder.icon+'"></div><div class="text"><div>'+data.placeholder.text+'</div></div></div>'));
					
					if(data.content){
						sheets.parse_object.set_current_object('section.section_block');
						$section_content = sheets.parse_object.init(data.content);
						if(data.section_visible == 'placeholder') $section_content.hide();
						$block.append($section_content);
					}
					return $block;
				},
				section_content: {
					init: function(data){
						
						var $content = $('<div class="content"></div>');
						if(data.summary){
							sheets.parse_object.set_current_object('section.section_block.section_content');
							var $summary = sheets.parse_object.init(data.summary);
							$content.append($summary);
						}
						if(data.field_set){
							sheets.parse_object.set_current_object('section.section_block.section_content');
							var $field_set = sheets.parse_object.init(data.field_set);
							$content.append($field_set);
						}
						return $content;
					},
					summary: {
						init: function(data){
							var $summary = $('<div class="section-summary"></div>');
							$.each(data.summary, function( index, field ){
								sheets.parse_object.set_current_object('section.section_block.section_content.summary');
								$summary.append($('<div class="summary-field" data-title="'+field.title+'" data-name="'+field.name+'" data-return="'+field.return+'"></div>'));
							});
							return $summary;
						}
					},
					field_set: {
						init: function(data){
							var $field_set = $('<div class="fields"></div>');
							$.each(data.fields, function( index, field ){
								sheets.parse_object.set_current_object('section.section_block.section_content.field_set');
								var $field = sheets.parse_object.init(field);
								$field_set.append($field);
							});
							return $field_set;
						},
						field: {
							init:	function(data){
								var $field = $('<div class="input-field"></div>');
								$field.newData('selected', (data.selected?'1':'0'));
								if(data.width) $field.addClass('width-'+data.width);
								switch(data.field_type){
									case 'text':
										$label = $('<label></label>');
										$input = $('<input type="text" name="'+data.name+'" value="'+data.value+'" />');
										if(data.data){
											$.each(data.data, function(key, value){
												$input.newData(key, value);
											});
										}
										$label.append(data.label);
										$label.append($input);
										$field.append($label);
									break;
									case 'hidden':
										$input = $('<input type="hidden" name="'+data.name+'" value="'+data.value+'" />');
										if(data.data){
											$.each(data.data, function(key, value){
												$input.newData(key, value);
											});
										}
										$field.append($input);
										$field.hide();
									break;
									case 'picker-single':
										$field.append($('<label>'+data.label+'</label>'));
										$.each(data.selected, function(value, text){
											$field.append(sheets.draw_field.picker_single(data.name, text, value, data.action, data.parent, data.icon));
										});								
										$field.append(sheets.draw_field.picker_single_default(data.name, data.text, data.action, data.parent, 'add_circle', data.icon));			
									break;
									case 'picker-multi':
										$field.append($('<label>'+data.label+'</label>'));
										$.each(data.selected, function(value, text){
											$field.append(sheets.draw_field.picker_multi(data.name, text, value, data.action, data.parent, data.icon));
										});
										$field.append(sheets.draw_field.picker_multi_default(data.name, data.text, data.action, data.parent, 'add_circle', data.icon));
									break;
								}
								return $field;
							}
						}
					}
				}
			}
		},
		
		picker: {
			init: function(data){
				sheets.parse_object.set_current_object('picker');
				var $wrapper = $('<div></div>');
				var $header = $('<div class="practice-sheet-header"></div>');
				var $row = $('<div class="row no-bottom-margin"></div>');
				$row.append($('<div class="col btn-header btn-close"><i class="material-icons">close</i></div>'));
				$row.append($('<div class="col f1"><h1>'+data.title+'</h1></div>'));
				$.each(data.actions, function(index, value){
					$row.append($('<div class="col btn-header btn-'+index+'" data-action="'+value+'"><i class="material-icons">'+index+'</i></div>'));
				});
				$header.append($row);
				
				var $content = $('<div class="practice-sheet-content"></div>');
				var $picker = $('<div class="picker container"></div>');
				$.each(data.blocks, function( index, block ){
					if(block.title) $picker.append($('<div class="picker-title">'+block.title+'</div>'));

					$.each(block.rows, function( index, row ){
						var $row = $('<div class="picker-row"></div>');
						$.each(row.data, function( index, value ){
							$row.newData(''+index,value);
						});
						$row.newData('action', data.return_action);
						if(data.field) $row.newData('field', data.field);
						$row.append($('<div class="row-icon"><i class="material-icons" style="color:'+row.color+';">'+row.icon+'</i></div>'));
						$row.append($('<div class="row-body-and-caption"><div>'+row.title+'</div><div>'+(row.caption?row.caption:'')+'</div></div>'));

						$picker.append($row);
					});
				});
				$content.append($picker);
				$wrapper.append($header);
				$wrapper.append($content);
				return $wrapper;
			}
		}
	},
	parse: function(data){
		sheets.parse_object.set_current_object('');
		return sheets.parse_object.init(data);
		
		switch(data.type){
			case 'section': 
				var $wrapper = $('<div></div>');
				var $header = $('<div class="practice-sheet-header"></div>');
				var $row = $('<div class="row no-bottom-margin"></div>');
				$row.append($('<div class="col btn-header btn-close"><i class="material-icons">close</i></div>'));
				$row.append($('<div class="col f1"><h1>'+data.title+'</h1></div>'));
				$row.append($('<div class="col btn-holder"><button class="btn btn-action" disabled>Save</button></div>'));
				$header.append($row);
				
				var $content = $('<div class="practice-sheet-content"></div>');
				$.each(data.blocks, function( index, block ){
					var $block = $('<div class="section container"></div>');
					if(block.editable) $block.addClass('section-editable');
					if(block.duplication) $block.addClass('section-duplication');
					
					$.each(block.data, function( index, value ){
						$block.newData(''+index, value);
					});
					
					$block.append($('<div class="section-title">'+block.title+'</div>'));
					$block.append($('<div class="empty-placeholder"'+(block.section_visible == 'placeholder'?'':' style="display:none;"')+'><div class="image '+block.placeholder.icon+'"></div><div class="text"><div>'+block.placeholder.text+'</div></div></div>'));
					
					if(block.content){
						$section_content = sheets.parse(block.content);
						if(block.section_visible == 'placeholder') $section_content.hide();
						$block.append($section_content);
					}
					$content.append($block);
					
				});
				
				$wrapper.append($header);
				$wrapper.append($content);
				
				return $wrapper;
			break;
			
			case 'section_content':		
				var $content = $('<div class="content"></div>');
				
				if(data.summary){
					var $summary = $('<div class="section-summary"></div>');
					$.each(data.summary, function( index, field ){
						$summary.append($('<div class="summary-field" data-title="'+field.title+'" data-name="'+field.name+'" data-return="'+field.return+'"></div>'));
					});
					$content.append($summary);
				}
				if(data.field_set){
					var $fields = $('<div class="fields"></div>');
					
					$.each(data.field_set.fields, function( index, field ){
						var $field = $('<div class="input-field"></div>');
						$field.newData('selected', (field.selected?'1':'0'));
						if(field.width) $field.addClass('width-'+field.width);
						switch(field.field_type){
							case 'text':
								$label = $('<label></label>');
								$input = $('<input type="text" name="'+field.name+'" value="'+field.value+'" />');
								if(field.data){
									$.each(field.data, function(key, value){
										$input.newData(key, value);
									});
								}
								$label.append(field.label);
								$label.append($input);
								$field.append($label);
							break;
							case 'hidden':
								$input = $('<input type="hidden" name="'+field.name+'" value="'+field.value+'" />');
								if(field.data){
									$.each(field.data, function(key, value){
										$input.newData(key, value);
									});
								}
								$field.append($input);
								$field.hide();
							break;
							case 'picker-single':
								$field.append($('<label>'+field.label+'</label>'));
								$.each(field.selected, function(value, text){
									$field.append(sheets.draw_field.picker_single(field.name, text, value, field.action, field.parent, field.icon));
								});								
								$field.append(sheets.draw_field.picker_single_default(field.name, field.text, field.action, field.parent, 'add_circle', field.icon));			
							break;
							case 'picker-multi':
								$field.append($('<label>'+field.label+'</label>'));
								$.each(field.selected, function(value, text){
									$field.append(sheets.draw_field.picker_multi(field.name, text, value, field.action, field.parent, field.icon));
								});								
								$field.append(sheets.draw_field.picker_multi_default(field.name, field.text, field.action, field.parent, 'add_circle', field.icon));
							break;
						}
						$fields.append($field);
					});
					$content.append($fields);
				}
				return $content;					
			break;
			
			case 'picker': 
				var $wrapper = $('<div></div>');
				var $header = $('<div class="practice-sheet-header"></div>');
				var $row = $('<div class="row no-bottom-margin"></div>');
				$row.append($('<div class="col btn-header btn-close"><i class="material-icons">close</i></div>'));
				$row.append($('<div class="col f1"><h1>'+data.title+'</h1></div>'));
				$.each(data.actions, function(index, value){
					$row.append($('<div class="col btn-header btn-'+index+'" data-action="'+value+'"><i class="material-icons">'+index+'</i></div>'));
				});
				$header.append($row);
				
				var $content = $('<div class="practice-sheet-content"></div>');
				var $picker = $('<div class="picker container"></div>');
				$.each(data.blocks, function( index, block ){
					if(block.title) $picker.append($('<div class="picker-title">'+block.title+'</div>'));

					$.each(block.rows, function( index, row ){
						var $row = $('<div class="picker-row"></div>');
						$.each(row.data, function( index, value ){
							$row.newData(''+index,value);
						});
						$row.newData('action', data.return_action);
						if(data.field) $row.newData('field', data.field);
						$row.append($('<div class="row-icon"><i class="material-icons" style="color:'+row.color+';">'+row.icon+'</i></div>'));
						$row.append($('<div class="row-body-and-caption"><div>'+row.title+'</div><div>'+(row.caption?row.caption:'')+'</div></div>'));

						$picker.append($row);
					});
				});
				$content.append($picker);
				$wrapper.append($header);
				$wrapper.append($content);
				return $wrapper;
			break;
			
		}		
	}
}